
What can this extension do?
This extension will ONLY record the KEYSTROKE and MOUSE movement data.
When the webpage on your chrome browser is active and you are logged into the extension, 
the extension can record your every keystroke (keyvalue and timing) and mouse movement information (pointer coordinates and timing). 
These data will be sent to the server and stored in a database for the further study.

Installation:
Step 1: Click the 'three dots' icon (Customise and control Google Chrome) at the right above of Chrome browser, go to More tools-->Extensions.
Step 2: Turn on the 'Developer mode'.
Step 3: Click 'Load unpacked' and find the location of the extension file, then click OK.
Then a new extension icon will appear.

Register:
1. Click the extension icon-->click Register
2. Fill in the form and submit (I recommend NOT to use your frequently used username and password). 

Login:
Enter the username and password on the popup page and click login.

Logout:
Click the logout button. If you do not want your sensitive data being recorded, simply click the logout button. 
When you are loggout, nothing will be recorded.

Checkstatus:
This button allows you to check whether you are logged in or not. 


